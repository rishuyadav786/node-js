// const express = require("express");
// var router = express.Router();
// //GET /
// router.get("/", (req, res) => {
//     res.header("Content-Type", "text/html").send("Home");
// });
// //GET /About
// router.get("/about", (req, res) => {
//     res.header("Content-Type", "text/html").send("About");
// });
// //GET /Contact
// router.get("/contact", (req, res) => {
//     res.header("Content-Type", "text/html").send("Contact");
// });


// module.exports=router;







const express = require("express");
var User =require("../model/user-model");
var bcrypt=require("bcryptjs");

var router = express.Router();
//GET /
router.get("/", (req, res) => {
    res.header("Content-Type", "text/html").render("index");
});
//GET /About
router.get("/about", (req, res) => {
    res.header("Content-Type", "text/html").render("about");
});
//GET /Contact
router.get("/contact", (req, res) => {
    res.header("Content-Type", "text/html").render("contact");
});
router.get("/add", (req, res) => {
    res.header("Content-Type", "text/html").render("add");
});

// router.get("/add", (req, res) => {
//     res.header("Content-Type", "text/html").render("register");
// });
router.post("/add", (req, res) => {
    var salt=bcrypt.genSaltSync(5);
    var formData=req.body;
    //console.log(formData);
    //res.send(formData);
    // res.header("Content-Type", "text/html").render("register");
    var user=new User({
        firstName:formData.name,
        email:formData.email,
        password:bcrypt.hashSync(formData.password,salt)
    });
    console.log(bcrypt.compareSync(formData.password,user.password));
    user.save(function(err){
        if(err){
            res.send("error in saving data");
        }
        res.send("Successfully saved");
    })
});


module.exports=router;