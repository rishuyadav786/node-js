# side-drawer-app



<!-- Auto Generated Below -->


## Properties

| Property | Attribute | Description | Type      | Default     |
| -------- | --------- | ----------- | --------- | ----------- |
| `opened` | `opened`  |             | `boolean` | `undefined` |
| `title`  | `title`   |             | `string`  | `undefined` |


## Methods

### `open() => Promise<void>`



#### Returns

Type: `Promise<void>`




----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
