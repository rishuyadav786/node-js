import { Component, h, Method, Prop, State } from "@stencil/core";

@Component({
    tag: 'side-drawer-app',
    styleUrl: './side-drawer.css',
    shadow: true
})
export class SideDrawer {
    //    @Prop() title:string;
    @Prop({ reflect: true }) title: string;
    @Prop({ reflect: true, mutable: true }) opened: boolean
    @State() showContactInfo = false
    onCloseDrawer() {
        this.opened = false
    }
    onContentChange(content: string) {
        console.log(content)
        this.showContactInfo = content === "contact"
    }
    @Method()
    open() {
        this.opened = true;
    }
    render() {

        // setTimeout(() => {
        //     this.open=true;
        // }, 4000);

        // let content =null;
        // if(this.open){
        //     content=(
        //         <aside>
        //         <header>
        //             <h1>{this.title}</h1>
        //         </header>
        //         <main>
        //         <slot/>
        //         </main>

        //         <h1>Welcome to my world!</h1>
        //     </aside> 
        //     )
        // }


        let mainContent = <slot />
        if (this.showContactInfo) {
            mainContent = (
                <div id="contavt-information">
                    <h2>Contact Information</h2>
                    <p>You can reach us via phone or email.</p>
                    <ul>
                        <li>Phone: 9804050418</li>
                        <li>E-mail: <a href="mailto:something@something.com">something@something.com</a></li>
                    </ul>
                </div>
            )
        }

        return [
            <div class="backdrop" onClick={this.onCloseDrawer.bind(this)}></div>,
            <aside>
                <header>
                    <h1>{this.title}</h1>
                    <button onClick={this.onCloseDrawer.bind(this)}>X</button>
                </header>
                <section id="tabs">
                    <button class={!this.showContactInfo ? 'active' : ''} onClick={this.onContentChange.bind(this, "nav")}>Navigation</button>
                    <button class={this.showContactInfo ? 'active' : ''} onClick={this.onContentChange.bind(this, "contact")}>Contacts</button>
                </section>
                <main>
                    {/* <slot/> */}
                    {mainContent}
                </main>

                <h1>Welcome to my world!</h1>
            </aside>
        ];
        // return content;
    }
}