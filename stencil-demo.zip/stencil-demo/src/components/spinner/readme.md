# uc-spinner



<!-- Auto Generated Below -->


## Dependencies

### Used by

 - [dashboard-app](../dashboard)
 - [stock-finder](../stock-finder)

### Graph
```mermaid
graph TD;
  dashboard-app --> uc-spinner
  stock-finder --> uc-spinner
  style uc-spinner fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
