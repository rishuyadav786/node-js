var path = require("path");
var fs = require("fs");

exports.requestHandler = ((req, res) => {
    //write the code to handle the request
    res.setHeader("content-type", "text/html");
    var layout = getViewContent("layout.html");

    if (req.url == "/") {
        var body = getViewContent("index.html");
        var content = layout.replace("{{body-content}}", body);
       var content1 = content.replace("{{url-name}}",req.url.slice(1));
  res.write(content1);
   
        res.end();
    }
    if (req.url == "/index") {
        var body = getViewContent("index.html");
        var content = layout.replace("{{body-content}}", body);
       var content1 = content.replace("{{url-name}}",req.url.slice(1));
  res.write(content1);
        res.end();
    }
    else if (req.url == "/about") {
        var body = getViewContent("about.html");
        var content = layout.replace("{{body-content}}", body);
       var content1 = content.replace("{{url-name}}",req.url.slice(1));
  res.write(content1);
        res.end();
    }
    else if (req.url == "/contact") {
        var body = getViewContent("contact.html");
        var content = layout.replace("{{body-content}}", body);
       var content1 = content.replace("{{url-name}}",req.url.slice(1));
  res.write(content1);
        res.end();
    }
    else if (req.url == "/register" && req.method == "GET") {
        var body = getViewContent("register.html");
        var content = layout.replace("{{body-content}}", body);
       var content1 = content.replace("{{url-name}}",req.url.slice(1));
  res.write(content1);
        res.end();
    }
    else if (req.url == "/register" && req.method == "POST") {
        var formData = "";
        req.on("data", (chunk) => {
            formData += chunk;

        });
        req.on("end", () => {
            res.write(formData);
            res.end();
        })

    }else if(req.url=="/style.css"){
        res.setHeader("content-type", "text/css");
        var style=getViewContent("style.css");
        res.write(style);
        res.end();
    }
    
});
function getViewContent(filename) {
    var filePath = path.resolve(__dirname, "views", filename);
    var content = fs.readFileSync(filePath);
    return content.toString();
}