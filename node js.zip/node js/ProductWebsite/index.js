// var http = require("http");
// var server = http.createServer((req, res) => {
//     //write the code to handle the request
//     res.setHeader("content-type", "text/html");
//     if (req.url == "/") {
//         res.write("<h2>This is home page....</h2>");
//     }
//     else if (req.url == "/about") {
//         res.write("<h2>This is about page</h2>");
//     }
//     else if (req.url == "/contact") {
//         res.write("<h2>This is Contact page</h2>");
//     }
//     res.end();
// });
// server.listen(5000, (err) => {
//     if (err) {
//         console.log("couldnot start server");
//         return;

//     }
//     console.log("server started in port 5000");
// })






var http = require("http");
// var { requestHandler } = require("./request-Handler");
const app=require("./server1");
// var server = http.createServer(requestHandler );
var server = http.createServer(app);
server.listen(5000, (err) => {
    if (err) {
        console.log("couldnot start server");
        return;

    }
    console.log("server started in port 5000");
})
