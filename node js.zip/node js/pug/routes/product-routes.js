const express=require("express");
var router=express.Router();
var products=[
    {id:1,name:"Apple",quantity:10,price:30},
    {id:2,name:"Orange",quantity:11,price:30},
    {id:3,name:"Mango",quantity:12,price:30},
    {id:4,name:"Banana",quantity:16,price:30},
    {id:5,name:"Grapes",quantity:18,price:30}
]
router.get("/list", (req, res) => {
    var model={
        caption:"Products List",
        items:products
    };
    res.header("Content-Type", "text/html").render("product-list",model);
});
router.get("/show", (req, res) => {
    res.header("Content-Type", "text/html").render("product-list",model);
});
router.get("/addhh", (req, res) => {
    res.header("Content-Type", "text/html").send("<h1>Product add</h1>");
});
module.exports=router;