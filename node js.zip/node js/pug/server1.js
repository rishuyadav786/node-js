const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const path=require("path");
const commonRoutes=require("./routes/common-routes");
const productRoutes=require("./routes/product-routes");


//create express app object
//the midleware

var app = express();
app.set("views","views");
app.set("view engine","pug");
app.use(express.static(path.resolve(__dirname,"public")));


app.use(cookieParser("mysecretKey"));
app.use(session({
    name: "session",
    resave: true,
    saveUninitialize: false,
    secret: "mysecretsessionkey"
}));

//configure routes
app.use("/",commonRoutes);
app.use("/products",productRoutes);
module.exports = app;
