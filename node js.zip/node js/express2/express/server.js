// const express = require("express");
// const bodyParser = require("body-parser");
// const cookieParser = require("cookie-parser");
// const session = require("express-session");
// var app = express();

// // app.use("/about",(req, res, next) => {
// app.use("/", test, (req, res, next) => {
//     // app.use((req, res, next) => {
//         req.author = "rishu";
//         req.verified = true;

//         next();
//     })
//     //create express app object

//     //configure request handler
//     app.get("/", (req, res) => {
//         res.header("Content-type", "text/html")
//             .send("<h2>Home page</h2>" + req.message);
//     });
//     app.get("/about", (req, res) => {
//         res.header("Content-type", "text/html")
//             .send("<h2>about page</h2>" + req.author);
//     });

//     app.get("/contact", (req, res) => {
//         res.header("Content-type", "text/html")
//             .send("<h2>Contact page</h2>" + req.author);
//     });

//     module.exports = app;

//     function test(req, res, next) {
//         req.message = "hello all";
//         next();
//     }













// const express = require("express");
// const bodyParser = require("body-parser");
// const cookieParser = require("cookie-parser");
// const Session = require("express-session");


// //create express app object

// var app = express();

// //configure middleware
// // app.use("/about", (req, res, next) => {
// app.use((req, res, next) => {
//     req.author = "Rishu";
//     req.verified = true;
//     next();
// })

// app.use(cookieParser());
// // configure request handlers
// app.get("/", homeMiddleware, (req, res) => {
//     res.cookie("company", "cap");
//     res.cookie("place", "blr");
//     res.header("content-type", "text/html").send("<h2>  bonjour home</h2>" + req.verified + " " + req.author + " " + req.message);
// });


// app.get("/about", (req, res) => {

//     res.header("content-type", "text/html").send("<h2>  bonjour about</h2>" + req.author);
// });

// app.get("/contact", contactMiddleware, (req, res) => {
//     var companyName = req.cookies.company || "nil";
//     var palceName = req.cookies.place || "nil";
//     res.clearCookie("company");
//     res.clearCookie("place");
//     res.header("content-type", "text/html").send(`<h2>  bonjour contact</h2> <p>company :${companyName} --${palceName}</p>`);
// });

// module.exports = app;


// // another way to apply middleware
// function homeMiddleware(req, res, next) {
//     req.message = "hello all home";
//     next();
// }
// function contactMiddleware(req, res, next) {
//     req.message = "hello from contact";
//     next();
// }











const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");


//create express app object

var app = express();

//configure middleware
// app.use("/about", (req, res, next) => {
app.use((req, res, next) => {
    req.author = "Rishu";
    req.verified = true;
    next();
})

// app.use(cookieParser());

app.use(cookieParser("mysecretKey"));
app.use(session({
    name: "session",
    resave: true,
    saveUninitialize: false,
    secret: "mysecretsessionkey"
}));
// configure request handlers
app.get("/", homeMiddleware, (req, res) => {
    res.cookie("company", "capgemini", { maxAge: 60000, expires: new Date(2018, 12, 31) });
    // res.cookie("company", "capgemini", { maxAge: 60000, expires: new Date(2018, 12, 31), secure: true });
    // res.cookie("company", "capgemini",{maxAge:60000,expires:new Date(2018,12,31),signed=true});
    res.cookie("place", "Banglore");
    res.header("content-type", "text/html").send("<h2>  home Page</h2>" + req.verified + " " + req.author + " " + req.message);
});


app.get("/about", (req, res) => {

    res.header("content-type", "text/html").send("<h2>  About page</h2>" + req.author);
});

app.get("/contact", contactMiddleware, (req, res) => {
    // var companyName=req.signedCookies.company || "NIL";
    var companyName = req.cookies.company || "nil";
    var palceName = req.cookies.place || "nil";
    res.clearCookie("company");
    res.clearCookie("place");
    res.header("content-type", "text/html").send(`<h2>Contact Page</h2> <p>company :${companyName} --${palceName}</p>`);
});

module.exports = app;


// another way to apply middleware
function homeMiddleware(req, res, next) {
    req.message = "hello all home";
    next();
}
function contactMiddleware(req, res, next) {
    req.message = "hello from contact";
    next();
}