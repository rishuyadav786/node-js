



const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const session = require("express-session");


//create express app object

var app = express();
// app.use(express.static(path.resolve(__dirname,"path")));
//configure middleware
// app.use("/about", (req, res, next) => {
app.use((req, res, next) => {
    req.author = "Rishu";
    req.verified = true;
    next();
})

// app.use(cookieParser());

app.use(cookieParser("mysecretKey"));
app.use(session({
    name: "session",
    resave: true,
    saveUninitialize: false,
    secret: "mysecretsessionkey"
}));
// configure request handlers
app.get("/", homeMiddleware, (req, res) => {
    res.cookie("company", "capgemini", { maxAge: 60000, expires: new Date(2018, 12, 31) });
    // res.cookie("company", "capgemini", { maxAge: 60000, expires: new Date(2018, 12, 31), secure: true });
    // res.cookie("company", "capgemini",{maxAge:60000,expires:new Date(2018,12,31),signed=true});
    res.cookie("place", "Banglore");
   req.session.Department="Cse";
   req.session.Salary=9804050;

    res.header("content-type", "text/html").send("<h2>  home Page</h2>" + req.verified + " " + req.author + " " + req.message);
});


app.get("/about", (req, res) => {

    res.header("content-type", "text/html").send("<h2>  About page</h2>" + req.author);
});

app.get("/contact", contactMiddleware, (req, res) => {
    // var companyName=req.signedCookies.company || "NIL";
    var companyName = req.cookies.company || "nil";
    var palceName = req.cookies.place || "nil";
    var dept = req.session.Department || "NIL";
    var salary = req.session.Salary || 0;
    res.clearCookie("company");
    res.clearCookie("place");
    req.session.destroy();
    res.header("content-type", "text/html").send(`<h2>Contact Page</h2>
     <p>company :${companyName} --${palceName}</p>
     <p>Department :  ${dept} <br>Salary : ${salary}</p>`);
});

module.exports = app;


// another way to apply middleware
function homeMiddleware(req, res, next) {
    req.message = "hello all home";
    next();
}
function contactMiddleware(req, res, next) {
    req.message = "hello from contact";
    next();
}